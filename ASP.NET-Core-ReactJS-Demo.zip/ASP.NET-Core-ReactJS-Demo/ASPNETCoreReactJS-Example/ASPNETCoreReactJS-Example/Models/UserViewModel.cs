﻿namespace ASPNETCoreReactJS_Example.Models
{
    public class UserViewModel
    {
        public string UserName { get; set; }

        public string FullName { get; set; }

        public string Email { get; set; }
    }
}