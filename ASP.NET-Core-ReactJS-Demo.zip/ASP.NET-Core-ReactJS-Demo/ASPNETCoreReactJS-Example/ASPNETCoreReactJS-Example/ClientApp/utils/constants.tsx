﻿export const ERROR_TEXT = "Something is wrong. But, you see, I'm just a baby, so I can't deal with everything in this cruel world! You wanna help me ?";

export const REPOSITORY_URL = "https://github.com/mdamyanova/ASP.NET-Core-ReactJS-Example";