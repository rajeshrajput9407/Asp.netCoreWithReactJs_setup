﻿import * as React from 'react';

export class Footer extends React.Component<{}, {}> {
    public render() {
        return (
            <footer>ASP.NET Core ReactJS - Example &copy; 2018</footer>
        );
    }
}